<?php
// index.php - Front Controller and Clean URL Router
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/Controller/AuthController.php';
require_once __DIR__ . '/Controller/AdminController.php';
require_once __DIR__ . '/Controller/TeacherController.php';
require_once __DIR__ . '/Controller/StudentController.php';
require_once __DIR__ . '/Controller/ReportController.php';

$url = $_GET['url'] ?? '';
$url = trim($url, '/');

// Default route
if (empty($url)) {
    if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
        header('Location: ' . BASE_URL . '/' . $_SESSION['role'] . '/dashboard');
        exit;
    } else {
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
}

// Router mapping
switch ($url) {
    // Auth & Common
    case 'login':
        (new AuthController())->showLogin();
        break;
    case 'login-action':
        (new AuthController())->loginAction();
        break;
    case 'logout':
        (new AuthController())->logoutAction();
        break;
    case 'change-password':
        (new AuthController())->showChangePassword();
        break;
    case 'change-password-action':
        (new AuthController())->changePasswordAction();
        break;
    case 'notifications':
        (new AuthController())->showNotifications();
        break;

    // Admin Routes
    case 'admin/dashboard':
        (new AdminController())->dashboard();
        break;
    case 'admin/departments':
        (new AdminController())->departments();
        break;
    case 'admin/teachers':
        (new AdminController())->teachers();
        break;
    case 'admin/students':
        (new AdminController())->students();
        break;
    case 'admin/courses':
        (new AdminController())->courses();
        break;
    case 'admin/assign-course':
        (new AdminController())->assignCourse();
        break;
    case 'admin/marks-approval':
        (new AdminController())->marksApproval();
        break;
    case 'admin/retake-appeals':
        (new AdminController())->retakeAppeals();
        break;
    case 'admin/reset-passwords':
        (new AdminController())->resetPasswords();
        break;
    case 'admin/reports':
        (new AdminController())->reports();
        break;
    case 'admin/announcements':
        (new AdminController())->announcements();
        break;

    // Teacher Routes
    case 'teacher/dashboard':
        (new TeacherController())->dashboard();
        break;
    case 'teacher/courses':
        (new TeacherController())->courses();
        break;
    case 'teacher/assessment-setup':
        (new TeacherController())->assessmentSetup();
        break;
    case 'teacher/marks-entry':
        (new TeacherController())->marksEntry();
        break;
    case 'teacher/withdraw-requests':
        (new TeacherController())->withdrawRequests();
        break;
    case 'teacher/profile':
        (new TeacherController())->profile();
        break;

    // Student Routes
    case 'student/dashboard':
        (new StudentController())->dashboard();
        break;
    case 'student/courses':
        (new StudentController())->courses();
        break;
    case 'student/withdraw-request':
        (new StudentController())->withdrawRequest();
        break;
    case 'student/results':
        (new StudentController())->results();
        break;
    case 'student/transcript':
        (new StudentController())->transcript();
        break;
    case 'student/retake-appeal':
        (new StudentController())->retakeAppeal();
        break;
    case 'student/print-marksheet':
        (new StudentController())->printMarksheet();
        break;

    // Reports / Exports
    case 'reports/transcript-print':
        (new ReportController())->printStudentTranscript();
        break;

    case 'documentation':
        require_once __DIR__ . '/documentation.html';
        break;

    default:
        http_response_code(404);
        echo "<!DOCTYPE html><html><head><title>404 Not Found</title><link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'></head><body class='bg-light d-flex align-items-center vh-100 justify-content-center'><div class='text-center'><h1 class='display-1 fw-bold text-primary'>404</h1><p class='fs-3'> <span class='text-danger'>Oops!</span> Page not found.</p><p class='lead'>The page you’re looking for doesn’t exist.</p><a href='" . BASE_URL . "/login' class='btn btn-primary'>Go Home</a></div></body></html>";
        break;
}