<?php
$page_title = 'Administrator Dashboard';
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
require_once __DIR__ . '/../layouts/navbar.php';
?>

<!-- Metric Stats Row -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-sm-6">
        <div class="card card-stat bg-white p-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-muted fw-normal mb-1">Total Students</h6>
                    <h3 class="fw-bold mb-0 text-primary"><?= $stats['total_students'] ?></h3>
                </div>
                <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-people-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-sm-6">
        <div class="card card-stat bg-white p-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-muted fw-normal mb-1">Faculty Members</h6>
                    <h3 class="fw-bold mb-0 text-success"><?= $stats['total_teachers'] ?></h3>
                </div>
                <div class="stat-icon bg-success bg-opacity-10 text-success">
                    <i class="bi bi-person-badge-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-sm-6">
        <div class="card card-stat bg-white p-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-muted fw-normal mb-1">Pending Marks Approval</h6>
                    <h3 class="fw-bold mb-0 text-warning"><?= $stats['pending_marks'] ?></h3>
                </div>
                <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                    <i class="bi bi-check2-circle"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-sm-6">
        <div class="card card-stat bg-white p-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-muted fw-normal mb-1">Retake Appeals (< C)</h6>
                    <h3 class="fw-bold mb-0 text-danger"><?= $stats['pending_appeals'] ?></h3>
                </div>
                <div class="stat-icon bg-danger bg-opacity-10 text-danger">
                    <i class="bi bi-arrow-repeat"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Marks Submissions Awaiting Approval -->
    <div class="col-lg-7">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-file-earmark-check me-2"></i>Faculty Marks Submissions</h6>
                <a href="<?= BASE_URL ?>/admin/marks-approval" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Course</th>
                                <th>Faculty</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_submissions)): ?>
                                <tr><td colspan="4" class="text-center text-muted py-4">No marks submissions found.</td></tr>
                            <?php else: ?>
                                <?php foreach (array_slice($recent_submissions, 0, 5) as $sub): ?>
                                    <tr>
                                        <td>
                                            <span class="fw-bold"><?= htmlspecialchars($sub['course_code']) ?></span>
                                            <small class="d-block text-muted"><?= htmlspecialchars($sub['course_title']) ?> (Sem <?= $sub['semester'] ?>)</small>
                                        </td>
                                        <td><?= htmlspecialchars($sub['teacher_name']) ?></td>
                                        <td>
                                            <?php if ($sub['marks_status'] === 'submitted'): ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-clock"></i> Awaiting Review</span>
                                            <?php else: ?>
                                                <span class="badge bg-success"><i class="bi bi-lock-fill"></i> Approved & Published</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <a href="<?= BASE_URL ?>/admin/marks-approval?assignment_id=<?= $sub['assignment_id'] ?>" class="btn btn-sm btn-primary">
                                                Review
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Retake Appeals -->
    <div class="col-lg-5">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h6 class="m-0 fw-bold text-danger"><i class="bi bi-arrow-repeat me-2"></i>Pending Retake Appeals</h6>
                <a href="<?= BASE_URL ?>/admin/retake-appeals" class="btn btn-sm btn-outline-danger">Manage</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Student</th>
                                <th>Course</th>
                                <th>Grade</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_appeals)): ?>
                                <tr><td colspan="4" class="text-center text-muted py-4">No pending retake appeals.</td></tr>
                            <?php else: ?>
                                <?php foreach (array_slice($recent_appeals, 0, 5) as $app): ?>
                                    <tr>
                                        <td>
                                            <span class="fw-bold"><?= htmlspecialchars($app['student_name']) ?></span>
                                            <small class="d-block text-muted"><?= htmlspecialchars($app['roll_no']) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($app['course_code']) ?></td>
                                        <td><span class="badge bg-danger"><?= htmlspecialchars($app['previous_grade']) ?> (<?= $app['previous_grade_point'] ?>)</span></td>
                                        <td class="text-end">
                                            <a href="<?= BASE_URL ?>/admin/retake-appeals" class="btn btn-xs btn-outline-primary btn-sm">Process</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>