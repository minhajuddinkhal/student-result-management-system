<?php
$page_title = 'Course Catalog (8 Semesters)';
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
require_once __DIR__ . '/../layouts/navbar.php';
?>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
        <h6 class="m-0 fw-bold text-primary"><i class="bi bi-journal-bookmark-fill me-2"></i>University Courses Across 8 Semesters</h6>
        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addCourseModal">
            <i class="bi bi-plus-lg me-1"></i> Add Course
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Code</th>
                        <th>Course Title</th>
                        <th>Credits</th>
                        <th>Department</th>
                        <th>Semester (1-8)</th>
                        <th>Type</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $c): ?>
                        <tr>
                            <td><span class="badge bg-secondary fs-6"><?= htmlspecialchars($c['course_code']) ?></span></td>
                            <td class="fw-bold"><?= htmlspecialchars($c['course_title']) ?></td>
                            <td><span class="badge bg-light text-dark border"><?= number_format($c['credit_hours'], 2) ?> Cr</span></td>
                            <td><span class="badge bg-info text-dark"><?= htmlspecialchars($c['dept_code']) ?></span></td>
                            <td><span class="badge bg-primary">Semester <?= $c['semester'] ?> (Year <?= ceil($c['semester']/2) ?>)</span></td>
                            <td><span class="badge bg-<?= $c['course_type'] === 'theory' ? 'success' : 'warning' ?>"><?= strtoupper($c['course_type']) ?></span></td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-secondary me-1" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#editCourseModal<?= $c['course_id'] ?>">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <form action="<?= BASE_URL ?>/admin/courses" method="POST" class="d-inline" onsubmit="return confirm('Delete this course?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="course_id" value="<?= $c['course_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>

                        <!-- Edit Course Modal -->
                        <div class="modal fade" id="editCourseModal<?= $c['course_id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <form action="<?= BASE_URL ?>/admin/courses" method="POST">
                                    <input type="hidden" name="action" value="edit">
                                    <input type="hidden" name="course_id" value="<?= $c['course_id'] ?>">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Course</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Course Code</label>
                                                <input type="text" name="course_code" class="form-control" value="<?= htmlspecialchars($c['course_code']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Course Title</label>
                                                <input type="text" name="course_title" class="form-control" value="<?= htmlspecialchars($c['course_title']) ?>" required>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label fw-semibold">Credit Hours</label>
                                                    <input type="number" step="0.5" name="credit_hours" class="form-control" value="<?= $c['credit_hours'] ?>" required>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label fw-semibold">Course Type</label>
                                                    <select name="course_type" class="form-select">
                                                        <option value="theory" <?= $c['course_type'] === 'theory' ? 'selected' : '' ?>>Theory</option>
                                                        <option value="lab" <?= $c['course_type'] === 'lab' ? 'selected' : '' ?>>Lab / Sessional</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label fw-semibold">Department</label>
                                                    <select name="dept_id" class="form-select" required>
                                                        <?php foreach ($departments as $d): ?>
                                                            <option value="<?= $d['dept_id'] ?>" <?= $d['dept_id'] == $c['dept_id'] ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($d['dept_code']) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label fw-semibold">Semester (1 to 8)</label>
                                                    <select name="semester" class="form-select" required>
                                                        <?php for ($sem = 1; $sem <= 8; $sem++): ?>
                                                            <option value="<?= $sem ?>" <?= $sem == $c['semester'] ? 'selected' : '' ?>>
                                                                Semester <?= $sem ?> (Year <?= ceil($sem/2) ?>)
                                                            </option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Course Modal -->
<div class="modal fade" id="addCourseModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= BASE_URL ?>/admin/courses" method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Course to Catalog</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Course Code</label>
                        <input type="text" name="course_code" class="form-control" placeholder="e.g. CSE-311" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Course Title</label>
                        <input type="text" name="course_title" class="form-control" placeholder="e.g. Operating Systems" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Credit Hours</label>
                            <input type="number" step="0.5" name="credit_hours" class="form-control" value="3.0" min="0.5" max="6.0" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Course Type</label>
                            <select name="course_type" class="form-select">
                                <option value="theory">Theory</option>
                                <option value="lab">Lab / Sessional</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Department</label>
                            <select name="dept_id" class="form-select" required>
                                <option value="">Select Department</option>
                                <?php foreach ($departments as $d): ?>
                                    <option value="<?= $d['dept_id'] ?>"><?= htmlspecialchars($d['dept_code']) ?> - <?= htmlspecialchars($d['dept_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Curriculum Semester (1-8)</label>
                            <select name="semester" class="form-select" required>
                                <?php for ($sem = 1; $sem <= 8; $sem++): ?>
                                    <option value="<?= $sem ?>">Semester <?= $sem ?> (Year <?= ceil($sem/2) ?>)</option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Course</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>