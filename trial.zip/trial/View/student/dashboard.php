<?php
$page_title = 'Student Academic Dashboard';
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
require_once __DIR__ . '/../layouts/navbar.php';
?>

<!-- Student Banner -->
<div class="card shadow-sm border-0 bg-primary text-white mb-4 p-4 rounded-4" style="background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%) !important;">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
        <div>
            <span class="badge bg-white text-primary mb-2 fw-semibold"><?= htmlspecialchars($student_info['dept_name']) ?></span>
            <h3 class="fw-bold mb-1"><?= htmlspecialchars($student_info['name']) ?></h3>
            <p class="mb-0 opacity-75">
                <span class="me-3"><strong>Roll:</strong> <?= htmlspecialchars($student_info['roll_no']) ?></span>
                <span class="me-3"><strong>Reg:</strong> <?= htmlspecialchars($student_info['reg_no']) ?></span>
                <span class="me-3"><strong>Current Status:</strong> Semester <?= $student_info['current_semester'] ?> (Year <?= ceil($student_info['current_semester']/2) ?>)</span>
                <span><strong>Session:</strong> <?= htmlspecialchars($student_info['academic_session']) ?></span>
            </p>
        </div>
        <div class="text-end bg-white bg-opacity-10 p-3 rounded-3 border border-white border-opacity-25">
            <small class="d-block text-white opacity-75 text-uppercase">Cumulative CGPA</small>
            <h2 class="fw-bold mb-0 text-warning"><?= number_format($transcript['cgpa'], 2) ?> <span class="fs-6 text-white">/ 4.00</span></h2>
            <small class="d-block text-white opacity-75"><?= $transcript['total_credits_earned'] ?> Credits Completed</small>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Active Courses with Assigned Teachers & Contact Info -->
    <div class="col-lg-8">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-journal-text me-2"></i>Current Enrolled Courses & Faculty Contacts</h6>
                <a href="<?= BASE_URL ?>/student/courses" class="btn btn-sm btn-outline-primary">View Courses</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Course</th>
                                <th>Credits</th>
                                <th>Assigned Teacher (Contact)</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($enrolled_courses)): ?>
                                <tr><td colspan="5" class="text-center py-4 text-muted">No course enrollments found for current term.</td></tr>
                            <?php else: ?>
                                <?php foreach ($enrolled_courses as $c): ?>
                                    <tr>
                                        <td>
                                            <span class="fw-bold d-block"><?= htmlspecialchars($c['course_code']) ?></span>
                                            <small class="text-muted"><?= htmlspecialchars($c['course_title']) ?></small>
                                        </td>
                                        <td><span class="badge bg-light text-dark border"><?= $c['credit_hours'] ?> Cr</span></td>
                                        <td>
                                            <span class="fw-bold d-block"><?= htmlspecialchars($c['teacher_name']) ?></span>
                                            <small><a href="mailto:<?= htmlspecialchars($c['teacher_email']) ?>" class="text-decoration-none"><i class="bi bi-envelope me-1"></i><?= htmlspecialchars($c['teacher_email']) ?></a></small>
                                            <small class="d-block text-muted"><i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($c['teacher_room'] ?? 'N/A') ?></small>
                                        </td>
                                        <td>
                                            <?php if ($c['status'] === 'withdrawn'): ?>
                                                <span class="badge bg-danger">Withdrawn</span>
                                            <?php elseif ($c['withdraw_status'] === 'pending'): ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-clock"></i> Withdraw Pending</span>
                                            <?php elseif ($c['is_published']): ?>
                                                <span class="badge bg-success">Result Published</span>
                                            <?php else: ?>
                                                <span class="badge bg-primary">In Progress</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <?php if ($c['status'] === 'enrolled' && !$c['is_published'] && empty($c['withdraw_status'])): ?>
                                                <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#withdrawModal<?= $c['enrollment_id'] ?>">
                                                    Withdraw
                                                </button>

                                                <!-- Withdraw Modal -->
                                                <div class="modal fade text-start" id="withdrawModal<?= $c['enrollment_id'] ?>" tabindex="-1">
                                                    <div class="modal-dialog">
                                                        <form action="<?= BASE_URL ?>/student/withdraw-request" method="POST">
                                                            <input type="hidden" name="enrollment_id" value="<?= $c['enrollment_id'] ?>">
                                                            <input type="hidden" name="assignment_id" value="<?= $c['assignment_id'] ?>">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Request Course Withdrawal</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p>Course: <strong><?= htmlspecialchars($c['course_code']) ?> - <?= htmlspecialchars($c['course_title']) ?></strong></p>
                                                                    <p>Teacher: <strong><?= htmlspecialchars($c['teacher_name']) ?></strong></p>
                                                                    <div class="alert alert-warning py-2 small">
                                                                        <i class="bi bi-exclamation-circle me-1"></i> Withdrawal requires formal approval from your assigned course instructor.
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label class="form-label fw-semibold">Reason for Course Withdrawal</label>
                                                                        <textarea name="reason" class="form-control" rows="3" placeholder="Please state your valid reason (e.g. medical, credit overload)..." required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-danger">Submit Withdrawal Request</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            <?php elseif (!empty($c['withdraw_status'])): ?>
                                                <span class="small text-muted"><?= ucfirst($c['withdraw_status']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Academic Actions & Notices -->
    <div class="col-lg-4">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-award-fill me-2"></i>Quick Results & Transcript</h6>
            </div>
            <div class="card-body">
                <p class="text-muted small">Access your complete 8-semester grading history, view SGPA/CGPA breakdowns, or generate an official printable marksheet.</p>
                <div class="d-grid gap-2">
                    <a href="<?= BASE_URL ?>/student/results" class="btn btn-outline-primary">
                        <i class="bi bi-list-stars me-1"></i> View Semester Results
                    </a>
                    <a href="<?= BASE_URL ?>/student/transcript" class="btn btn-outline-success">
                        <i class="bi bi-file-earmark-spreadsheet me-1"></i> Full Academic Transcript
                    </a>
                    <a href="<?= BASE_URL ?>/student/print-marksheet" target="_blank" class="btn btn-primary">
                        <i class="bi bi-printer me-1"></i> Print Official Marksheet
                    </a>
                </div>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="m-0 fw-bold text-secondary"><i class="bi bi-megaphone me-2"></i>Campus Notices</h6>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if (empty($announcements)): ?>
                        <div class="text-center py-4 text-muted small">No new announcements.</div>
                    <?php else: ?>
                        <?php foreach (array_slice($announcements, 0, 3) as $a): ?>
                            <div class="list-group-item p-3">
                                <h6 class="fw-bold mb-1 small text-dark"><?= htmlspecialchars($a['title']) ?></h6>
                                <p class="small text-muted mb-0 text-truncate"><?= htmlspecialchars($a['content']) ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>