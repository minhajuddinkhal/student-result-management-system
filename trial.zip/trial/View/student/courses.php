<?php
$page_title = 'My Enrolled Courses & Assigned Faculty';
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
require_once __DIR__ . '/../layouts/navbar.php';
?>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
        <div>
            <h6 class="m-0 fw-bold text-primary"><i class="bi bi-journal-check me-2"></i>All Enrolled Courses & Faculty Contacts</h6>
            <small class="text-muted">You can communicate with your assigned instructors using their email addresses displayed below, or submit a course withdrawal request if needed.</small>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Course Code & Title</th>
                        <th>Credits</th>
                        <th>Semester & Session</th>
                        <th>Assigned Faculty Member (Email & Room)</th>
                        <th>Enrollment Type</th>
                        <th>Status</th>
                        <th class="text-end">Withdraw Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($enrolled_courses)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">No courses registered.</td></tr>
                    <?php else: ?>
                        <?php foreach ($enrolled_courses as $c): ?>
                            <tr>
                                <td>
                                    <span class="fw-bold d-block"><?= htmlspecialchars($c['course_code']) ?></span>
                                    <span class="text-muted"><?= htmlspecialchars($c['course_title']) ?></span>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?= number_format($c['credit_hours'], 2) ?> Cr</span></td>
                                <td><span class="badge bg-primary">Sem <?= $c['semester'] ?></span> (<?= htmlspecialchars($c['academic_year']) ?>)</td>
                                <td>
                                    <span class="fw-bold d-block"><?= htmlspecialchars($c['teacher_name']) ?></span>
                                    <a href="mailto:<?= htmlspecialchars($c['teacher_email']) ?>" class="badge bg-light text-primary border text-decoration-none mb-1">
                                        <i class="bi bi-envelope me-1"></i><?= htmlspecialchars($c['teacher_email']) ?>
                                    </a>
                                    <small class="d-block text-muted"><i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($c['teacher_room'] ?? 'Office Room') ?></small>
                                </td>
                                <td>
                                    <?php if ($c['enrollment_type'] === 'retake'): ?>
                                        <span class="badge bg-danger">Course Retake</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Regular</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($c['status'] === 'withdrawn'): ?>
                                        <span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i> Withdrawn</span>
                                    <?php elseif ($c['withdraw_status'] === 'pending'): ?>
                                        <span class="badge bg-warning text-dark"><i class="bi bi-hourglass-split me-1"></i> Withdrawal Requested</span>
                                    <?php elseif ($c['is_published']): ?>
                                        <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i> Completed & Published</span>
                                    <?php else: ?>
                                        <span class="badge bg-info text-dark">Active Enrollment</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <?php if ($c['status'] === 'enrolled' && !$c['is_published'] && empty($c['withdraw_status'])): ?>
                                        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#withdrawModal<?= $c['enrollment_id'] ?>">
                                            <i class="bi bi-box-arrow-right me-1"></i> Request Withdraw
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade text-start" id="withdrawModal<?= $c['enrollment_id'] ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <form action="<?= BASE_URL ?>/student/withdraw-request" method="POST">
                                                    <input type="hidden" name="enrollment_id" value="<?= $c['enrollment_id'] ?>">
                                                    <input type="hidden" name="assignment_id" value="<?= $c['assignment_id'] ?>">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Withdraw from <?= htmlspecialchars($c['course_code']) ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Course: <strong><?= htmlspecialchars($c['course_title']) ?></strong></p>
                                                            <p>Assigned Instructor: <strong><?= htmlspecialchars($c['teacher_name']) ?></strong></p>
                                                            <div class="alert alert-info py-2 small">
                                                                <i class="bi bi-info-circle me-1"></i> Your request will be sent directly to <strong><?= htmlspecialchars($c['teacher_name']) ?></strong> for approval.
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label fw-semibold">Reason for Course Withdrawal</label>
                                                                <textarea name="reason" class="form-control" rows="3" placeholder="Explain your reason clearly..." required></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-danger">Confirm & Send Request</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    <?php elseif (!empty($c['withdraw_status'])): ?>
                                        <span class="badge bg-light text-muted border">Request <?= ucfirst($c['withdraw_status']) ?></span>
                                    <?php else: ?>
                                        <span class="text-muted small">N/A</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>